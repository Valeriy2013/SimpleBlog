var posts = require('../database/posts'),
  getNextId = require('./getNextId'),
  url = require('url');

var nextId = getNextId(posts);

exports.getPosts = function(req, res) {
  res.send(posts);
}

exports.getPost = function(req, res) {
  var post = posts.find(post => post.id === +req.params.postId);
  res.send(post);
}

exports.savePost = function(req, res) {
  var post = req.body;
  
  if (post.id) {
    var index = posts.findIndex(e => e.id === post.id)
    posts[index] = post
  } else {
    post.id = nextId;
    nextId++;
    posts.push(post);
  }
  res.send(post);
  res.end(); 
}


