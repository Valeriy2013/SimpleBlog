var users = [{
  id: 1,
  userName: "user1",
  firstName: "Ivan",
  lastName: "Ivanov"
},{
  id: 2,
  userName: "user2",
  firstName: "Petr",
  lastName: "Petrov"
}];

module.exports = users;