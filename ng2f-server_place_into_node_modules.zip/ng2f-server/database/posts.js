
var posts = [
    {
            id: 1,
            title: 'Post #1 title',
            body: `Post #1 body
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
            `,
            date: '3/3/2017'
    },
    {
            id: 2,
            title: 'Post #2 title',
            body: `Post #2 body
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
            `,
            date: '12/3/2017'
    },
    {
            id: 3,
            title: 'Post #3 title',
            body: `Post #3 body
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
            `,
            date: '3/1/2017'
    },
    {
            id: 4,
            title: 'Post #4 title',
            body: `Post #4 body
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
            `,
            date: '10/11/2017'
    },
    {
            id: 5,
            title: 'Post #5 title',
            body: `Post #5 body
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
            `,
            date: '12/11/2017'
    },
    {
            id: 6,
            title: 'Post #6 title',
            body: `Post #6 body
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
                qwe asd zcx ads qwe asd zcc
            `,
            date: '11/11/2017'
    },

]

module.exports = posts;