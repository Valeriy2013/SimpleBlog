var auth = require('./auth'),
  posts = require('./controllers/postController'),
  users = require('./controllers/userController');
  path = require('path');

var fs = require('fs');


module.exports = function(app) {

  app.post('/api/login', auth.authenticate);
  app.get('/api/currentIdentity', auth.getCurrentIdentity);
  app.put('/api/users/:id', users.updateUser);
  
  app.get('/api/posts', posts.getPosts);
  app.get('/api/posts/:postId', posts.getPost);
  app.post('/api/posts', posts.savePost);
  
  app.post('/api/logout', function(req, res) {
    req.logout();
    res.end();
  });
  
  app.get('/app/*', function(req, res) {
    res.sendStatus(404);
  });
  
  app.get('/node_modules/*', function(req, res) {
    res.sendStatus(404);
  });

  app.get('/posts/*', function(req, res) {
    res.sendFile(path.resolve(__dirname + '/../../index.html'));
  });
  app.get('/user/*', function(req, res) {
    res.sendFile(path.resolve(__dirname + '/../../index.html'));
  });
  app.get('/404', function(req, res) {
    res.sendFile(path.resolve(__dirname + '/../../index.html'));
  });
  
  app.get('*', function(req, res) {
    console.log('404 error', req.path);
    res.sendStatus(404);
  });
}